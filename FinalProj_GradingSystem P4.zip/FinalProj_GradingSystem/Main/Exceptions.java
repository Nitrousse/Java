package Main;

public class Exceptions {
    
}
