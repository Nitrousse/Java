package Main;

import java.util.List;

public class Teacher extends User {
    public Teacher(int id, String name, String username, String password) {
        super(id, name, username, password);
    }

    public void assignGradeComponent(List<Grade> grades, int studentId, int subjectId,
                                     double quiz1, double quiz2, double activities, double midterm, double finalExam) {
        Grade grade = grades.stream()
                .filter(g -> g.getStudentId() == studentId && g.getSubjectId() == subjectId)
                .findFirst()
                .orElse(null);

        if (grade == null) {
            grade = new Grade(studentId, subjectId);
            grades.add(grade);
        }

        grade.setQuiz1(quiz1);
        grade.setQuiz1(quiz2);
        grade.setActivities(activities);
        grade.setMidterm(midterm);
        grade.setFinalExam(finalExam);
        grade.calculateOverallScore();

        System.out.println("Grades updated for Student ID: " + studentId + ", Subject ID: " + subjectId);
    }

    public void calculateAverageGrade(List<Grade> grades, int studentId) {
        double totalScore = 0;
        int count = 0;

        for (Grade grade : grades) {
            if (grade.getStudentId() == studentId) {
                totalScore += grade.getOverallScore();
                count++;
            }
        }

        if (count > 0) {
            System.out.printf("Average Grade for Student ID %d: %.2f\n", studentId, totalScore / count);
        } else {
            System.out.println("No grades found for the student.");
        }
    }
}
