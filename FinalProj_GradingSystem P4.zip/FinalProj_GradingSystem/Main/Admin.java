package Main;

import java.util.ArrayList;
import java.util.List;

public class Admin extends User {
    private final List<Enrollment> enrollments;

    public Admin(int id, String name, String username, String password) {
        super(id, name, username, password);
        this.enrollments = new ArrayList<>();
    }

    public void viewGrades(List<Grade> grades) {
        System.out.println("\n=== All Grades ===");
        grades.forEach(System.out::println);
    }

    public void viewSubjects(List<Subject> subjects) {
        System.out.println("\n=== All Subjects ===");
        subjects.forEach(subject -> System.out.println("Subject ID: " + subject.getSubjectID() +
                ", Subject Name: " + subject.getSubjectName()));
    }

    public void enrollStudent(int studentId, int subjectId) {
        enrollments.add(new Enrollment(studentId, subjectId));
        System.out.println("Student " + studentId + " enrolled in Subject " + subjectId);
    }

    public void viewEnrollments() {
        System.out.println("\n=== Enrollments ===");
        if (enrollments.isEmpty()) {
            System.out.println("No enrollments found.");
        } else {
            enrollments.forEach(System.out::println);
        }
    }
    public void viewGrades(List<Grade> grades, List<User> users) {
        System.out.println("\n=== All Grades ===");
        if (grades.isEmpty()) {
            System.out.println("No grades available.");
        } else {
            for (Grade grade : grades) {
                User student = users.stream()
                        .filter(user -> user.getUserID() == grade.getStudentId())
                        .findFirst()
                        .orElse(null);
                String studentName = (student != null) ? student.getName() : "Unknown";
                System.out.println("Student Name: " + studentName + ", " + grade.toString());
            }
        }
    }
    
    public void viewEnrollments(List<User> users) {
        System.out.println("\n=== Enrollments ===");
        if (enrollments.isEmpty()) {
            System.out.println("No enrollments found.");
        } else {
            for (Enrollment enrollment : enrollments) {
                User student = users.stream()
                        .filter(user -> user.getUserID() == enrollment.getStudentId())
                        .findFirst()
                        .orElse(null);
                String studentName = (student != null) ? student.getName() : "Unknown";
                System.out.println("Student Name: " + studentName + ", Subject ID: " + enrollment.getSubjectId());
            }
        }
    }
    
}
