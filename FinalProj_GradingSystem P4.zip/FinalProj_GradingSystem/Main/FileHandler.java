package Main;

import java.io.*;
import java.util.List;

public class FileHandler {
    public static void loadGrades(List<Grade> grades, String fileName) throws IOException {
        File file = new File(fileName);
        if (!file.exists() || file.length() == 0) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 8) continue;

                int studentId = Integer.parseInt(parts[0]);
                int subjectId = Integer.parseInt(parts[1]);
                double quiz1 = Double.parseDouble(parts[2]);
                double quiz2 = Double.parseDouble(parts[3]);
                double activities = Double.parseDouble(parts[4]);
                double midterm = Double.parseDouble(parts[5]);
                double finalExam = Double.parseDouble(parts[6]);

                Grade grade = new Grade(studentId, subjectId);
                grade.setQuiz1(quiz1);
                grade.setQuiz1(quiz2);
                grade.setActivities(activities);
                grade.setMidterm(midterm);
                grade.setFinalExam(finalExam);
                grade.calculateOverallScore();
                grades.add(grade);
            }
        }
    }

    public static void saveGrades(List<Grade> grades, String fileName) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Grade grade : grades) {
                writer.write(grade.toCSV());
                writer.newLine();
            }
        }
    }

    public static void loadSubjects(List<Subject> subjects, String fileName) throws IOException {
        File file = new File(fileName);
        if (!file.exists() || file.length() == 0) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int subjectId = Integer.parseInt(parts[0]);
                String subjectName = parts[1];
                subjects.add(new Subject(subjectId, subjectName));
            }
        }
    }

    public static void saveSubjects(List<Subject> subjects, String fileName) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Subject subject : subjects) {
                writer.write(subject.getSubjectID() + "," + subject.getSubjectName());
                writer.newLine();
            }
        }
    }
}
