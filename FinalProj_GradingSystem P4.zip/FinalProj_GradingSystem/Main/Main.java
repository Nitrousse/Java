package Main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final String DATA_FILE = "grades.txt";
    private static final String SUBJECT_FILE = "subjects.txt";
    private static List<Grade> grades = new ArrayList<>();
    private static List<Subject> subjects = new ArrayList<>();
    private static List<User> users = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            FileHandler.loadGrades(grades, DATA_FILE);
            FileHandler.loadSubjects(subjects, SUBJECT_FILE);
            System.out.println("Grades and Subjects loaded successfully.");
        } catch (IOException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }

        users.add(new Admin(1, "Admin User", "admin", "adminpass"));
        users.add(new Teacher(2, "John Doe", "teacher", "teacherpass"));
        users.add(new Student(3, "Alice Brown", "student", "studentpass"));
        // Initialize subjects
        subjects.add(new Subject(101, "Mathematics"));
        subjects.add(new Subject(102, "Science"));
        subjects.add(new Subject(103, "History"));

        while (true) {
            User loggedInUser = login();
            if (loggedInUser == null) {
                System.out.println("Invalid credentials. Try again.");
                continue;
            }

            if (loggedInUser instanceof Admin) {
                adminMenu((Admin) loggedInUser);
            } else if (loggedInUser instanceof Teacher) {
                teacherMenu((Teacher) loggedInUser);
            } else if (loggedInUser instanceof Student) {
                studentMenu((Student) loggedInUser);
            }
        }
    }

    private static User login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        return users.stream()
                .filter(user -> user.getUsername().equals(username) && user.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }

    private static void adminMenu(Admin admin) {
        while (true) {
            System.out.println("\n=== Admin Menu ===");
            System.out.println("1. View All Grades");
            System.out.println("2. View All Subjects");
            System.out.println("3. Enroll Student in Subject");
            System.out.println("4. View Enrollments");
            System.out.println("5. Add New Student");
            System.out.println("6. Add New Subject");
            System.out.println("7. Save and Logout");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
    
            switch (choice) {
                case 1 -> admin.viewGrades(grades, users);
                case 2 -> admin.viewSubjects(subjects);
                case 3 -> enrollStudent(admin);
                case 4 -> admin.viewEnrollments(users);
                case 5 -> addNewStudent();
                case 6 -> addNewSubject();
                case 7 -> {
                saveData();
            return; // Logout
                        }
            default -> System.out.println("Invalid option. Try again.");
                    }
                }
            }
                    
                
            private static void addNewStudent() {
                System.out.print("Enter Student ID: ");
                int studentID = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
                System.out.print("Enter Student Name: ");
                String name = scanner.nextLine();
                System.out.print("Enter Username: ");
                String username = scanner.nextLine();
                System.out.print("Enter Password: ");
                String password = scanner.nextLine();
            
                // Check if the student ID or username already exists
                boolean userExists = users.stream()
                        .anyMatch(user -> user.getUserID() == studentID || user.getUsername().equals(username));
            
                if (userExists) {
                    System.out.println("A user with this ID or username already exists. Try again.");
                } else {
                    users.add(new Student(studentID, name, username, password));
                    System.out.println("Student added successfully.");
                }
            }
            
                
        private static void enrollStudent(Admin admin) {
        System.out.print("Enter Student ID: ");
        int studentID = scanner.nextInt();
        System.out.print("Enter Subject ID: ");
        int subjectID = scanner.nextInt();
        scanner.nextLine();

        boolean studentExists = users.stream().anyMatch(user -> user.getUserID() == studentID && user instanceof Student);
        boolean subjectExists = subjects.stream().anyMatch(subject -> subject.getSubjectID() == subjectID);

        if (!studentExists) {
            System.out.println("Student not found.");
            return;
        }

        if (!subjectExists) {
            System.out.println("Subject not found.");
            return;
        }

        admin.enrollStudent(studentID, subjectID);
        System.out.println("Enrollment successful.");
    }

    private static void teacherMenu(Teacher teacher) {
        while (true) {
            System.out.println("\n=== Teacher Menu ===");
            System.out.println("1. Assign Grade");
            System.out.println("2. Calculate Average Grade");
            System.out.println("3. Save and Logout");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> assignGrade(teacher);
                case 2 -> {
                    System.out.print("Enter Student ID: ");
                    int studentID = scanner.nextInt();
                    teacher.calculateAverageGrade(grades, studentID);
                }
                case 3 -> {
                    saveData();
                    return;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void assignGrade(Teacher teacher) {
        System.out.print("Enter Student ID: ");
        int studentID = scanner.nextInt();
        System.out.print("Enter Subject ID: ");
        int subjectID = scanner.nextInt();
        System.out.print("Enter Quiz 1 Score (out of 10): ");
        double quiz1 = scanner.nextDouble();
        System.out.print("Enter Quiz 2 Score (out of 10): ");
        double quiz2 = scanner.nextDouble();
        System.out.print("Enter Activities Score (out of 100): ");
        double activities = scanner.nextDouble();
        System.out.print("Enter Midterm Score (out of 100): ");
        double midterm = scanner.nextDouble();
        System.out.print("Enter Final Exam Score (out of 100): ");
        double finalExam = scanner.nextDouble();

        teacher.assignGradeComponent(grades, studentID, subjectID, quiz1, quiz2, activities, midterm, finalExam);
    }

    private static void studentMenu(Student student) {
        while (true) {
            System.out.println("\n=== Student Menu ===");
            System.out.println("1. View Grades");
            System.out.println("2. Logout");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
    
            switch (choice) {
                case 1 -> student.viewGrades(grades);
                case 2 -> {
                    return;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    

    private static void addNewSubject() {
        System.out.print("Enter Subject ID: ");
        int subjectID = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Subject Name: ");
        String subjectName = scanner.nextLine();
    
        // Check if subject ID already exists
        boolean subjectExists = subjects.stream().anyMatch(subject -> subject.getSubjectID() == subjectID);
    
        if (subjectExists) {
            System.out.println("A subject with this ID already exists.");
        } else {
            subjects.add(new Subject(subjectID, subjectName));
            System.out.println("Subject added successfully.");
        }
    }
    

    private static void saveData() {
        try {
            FileHandler.saveGrades(grades, DATA_FILE);
            FileHandler.saveSubjects(subjects, SUBJECT_FILE);
            System.out.println("Data saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }
}
