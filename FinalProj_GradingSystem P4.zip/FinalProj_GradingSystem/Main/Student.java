package Main;

import java.util.List;

public class Student extends User {
    public Student(int id, String name, String username, String password) {
        super(id, name, username, password);
    }

    public void viewGrades(List<Grade> grades) {
        System.out.println("\n=== Your Grades ===");
        boolean hasGrades = false;

        for (Grade grade : grades) {
            if (grade.getStudentId() == this.getUserID()) {
                System.out.println(grade.toString());
                hasGrades = true;
            }
        }

        if (!hasGrades) {
            System.out.println("No grades available.");
        }
    }
}
