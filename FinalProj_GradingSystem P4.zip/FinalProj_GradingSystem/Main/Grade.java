package Main;

public class Grade {
    private final int studentId;
    private final int subjectId;
    private double quiz1;
    private double quiz2;
    private double activities;
    private double midterm;
    private double finalExam;
    private double overallScore;

    public Grade(int studentId, int subjectId) {
        this.studentId = studentId;
        this.subjectId = subjectId;
    }

    // Getters
    public int getStudentId() {
        return studentId;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public double getQuiz1() {
        return quiz1;
    }

    public double getQuiz2() {
        return quiz2;
    }

    public double getActivities() {
        return activities;
    }

    public double getMidterm() {
        return midterm;
    }

    public double getFinalExam() {
        return finalExam;
    }

    public double getOverallScore() {
        return overallScore;
    }

    // Setters
    public void setQuiz1(double quiz1) {
        this.quiz1 = quiz1;
    }

    public void setQuiz2(double quiz2) {
        this.quiz2 = quiz2;
    }

    public void setActivities(double activities) {
        this.activities = activities;
    }

    public void setMidterm(double midterm) {
        this.midterm = midterm;
    }

    public void setFinalExam(double finalExam) {
        this.finalExam = finalExam;
    }

    // Calculate Overall Score
    public void calculateOverallScore() {
        double averageQuizzes = ((quiz1 + quiz2) / 20) * 100;
        overallScore = (averageQuizzes * 0.25) + (activities * 0.25) + (midterm * 0.25) + (finalExam * 0.25);
    }

    // Convert to CSV for file saving
    public String toCSV() {
        return studentId + "," + subjectId + "," + quiz1 + "," + quiz2 + "," +
               activities + "," + midterm + "," + finalExam + "," + overallScore;
    }

    @Override
    public String toString() {
        return "Student ID: " + studentId +
               ", Subject ID: " + subjectId +
               ", Quizzes: " + quiz1 + ", " + quiz2 +
               ", Activities: " + activities +
               ", Midterm: " + midterm +
               ", Final Exam: " + finalExam +
               ", Final Grade: " + overallScore;
    }
}
