package Main;

public class Enrollment {
    private final int studentId;
    private final int subjectId;

    public Enrollment(int studentId, int subjectId) {
        this.studentId = studentId;
        this.subjectId = subjectId;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getSubjectId() {
        return subjectId;
    }

    @Override
    public String toString() {
        return "Student ID: " + studentId + ", Subject ID: " + subjectId;
    }
}
