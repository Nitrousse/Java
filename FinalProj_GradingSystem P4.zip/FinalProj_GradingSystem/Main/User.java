package Main;

public abstract class User {
    protected int userID;
    protected String name;
    protected String username;
    protected String password;

    public User(int userID, String name, String username, String password) {
        this.userID = userID;
        this.name = name;
        this.username = username;
        this.password = password;
    }
    public String getName() {
        return name;
    }    

    public int getUserID() {
        return userID;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Username: " + username);
    }
}
